"""扫描器基类"""
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
import subprocess
import shutil
from pathlib import Path


class ScanResult:
    """扫描结果数据类"""
    
    def __init__(
        self,
        name: str,
        version: str,
        item_type: str,
        install_method: str,
        detection_source: str = "",
        auto_install_command: str = "",
        download_url: str = "",
        install_guide: str = "",
        verify_command: str = "",
        notes: str = "",
        priority: int = 3,
        **extra_data
    ):
        """
        初始化扫描结果
        
        Args:
            name: 项目名称
            version: 版本号
            item_type: 类型（language/package/tool/ide_plugin）
            install_method: 安装方式（auto/semi_auto/manual）
            detection_source: 检测来源
            auto_install_command: 自动安装命令
            download_url: 下载链接
            install_guide: 安装指南
            verify_command: 验证命令
            notes: 备注
            priority: 优先级（1-5，5最高）
            extra_data: 额外数据
        """
        self.name = name
        self.version = version
        self.item_type = item_type
        self.install_method = install_method
        self.detection_source = detection_source
        self.auto_install_command = auto_install_command
        self.download_url = download_url
        self.install_guide = install_guide
        self.verify_command = verify_command
        self.notes = notes
        self.priority = priority
        self.extra_data = extra_data
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        result = {
            "name": self.name,
            "version": self.version,
            "item_type": self.item_type,
            "install_method": self.install_method,
            "detection_source": self.detection_source,
            "priority": self.priority
        }
        
        # 只添加非空字段
        if self.auto_install_command:
            result["auto_install_command"] = self.auto_install_command
        if self.download_url:
            result["download_url"] = self.download_url
        if self.install_guide:
            result["install_guide"] = self.install_guide
        if self.verify_command:
            result["verify_command"] = self.verify_command
        if self.notes:
            result["notes"] = self.notes
        
        # 添加额外数据
        result.update(self.extra_data)
        
        return result


class BaseScanner(ABC):
    """扫描器基类"""
    
    def __init__(self, logger=None):
        """
        初始化扫描器
        
        Args:
            logger: 日志记录器
        """
        self.logger = logger
        self.results: List[ScanResult] = []
    
    @abstractmethod
    def scan(self) -> List[ScanResult]:
        """
        执行扫描
        
        Returns:
            List[ScanResult]: 扫描结果列表
        """
        pass
    
    def _run_command(self, command: str, shell: bool = True, use_cmd: bool = False, capture_stderr: bool = False) -> Optional[str]:
        """
        执行命令并返回输出
        
        Args:
            command: 要执行的命令
            shell: 是否使用shell
            use_cmd: 是否使用 CMD（用于 nvm 等命令）
            capture_stderr: 是否也捕获 stderr（用于 Java 等命令）
        
        Returns:
            str: 命令输出，失败返回None
        """
        try:
            # 对于 nvm 等需要真实终端的命令，使用 CMD
            if use_cmd:
                # 使用 cmd /c 来执行命令
                command = f'cmd /c "{command}"'
            
            result = subprocess.run(
                command,
                shell=shell,
                capture_output=True,
                text=True,
                timeout=10,
                encoding='utf-8',
                errors='ignore'
            )
            if result.returncode == 0 or (capture_stderr and result.stderr):
                # 某些命令（如 java -version）将版本信息输出到 stderr
                output = result.stdout.strip()
                if capture_stderr and result.stderr:
                    output = output + "\n" + result.stderr.strip()
                return output if output else None
            return None
        except Exception as e:
            if self.logger:
                self.logger.debug(f"命令执行失败 '{command}': {e}")
            return None
    
    def _check_command_exists(self, command: str) -> bool:
        """
        检查命令是否存在
        
        Args:
            command: 命令名称
        
        Returns:
            bool: 是否存在
        """
        return shutil.which(command) is not None
    
    def _get_version(self, command: str, version_flag: str = "--version") -> Optional[str]:
        """
        获取软件版本
        
        Args:
            command: 命令名称
            version_flag: 版本参数
        
        Returns:
            str: 版本号，失败返回None
        """
        if not self._check_command_exists(command):
            return None
        
        output = self._run_command(f"{command} {version_flag}")
        if output:
            # 尝试提取版本号（简单实现）
            import re
            version_match = re.search(r'(\d+\.[\d.]+)', output)
            if version_match:
                return version_match.group(1)
            return output.split('\n')[0]  # 返回第一行
        return None
    
    def _file_exists(self, path: str) -> bool:
        """检查文件是否存在"""
        return Path(path).exists()
    
    def _read_file(self, path: str) -> Optional[str]:
        """读取文件内容"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            if self.logger:
                self.logger.debug(f"读取文件失败 '{path}': {e}")
            return None
    
    def log_info(self, message: str):
        """记录信息日志"""
        if self.logger:
            self.logger.info(message)
    
    def log_warning(self, message: str):
        """记录警告日志"""
        if self.logger:
            self.logger.warning(message)
    
    def log_error(self, message: str):
        """记录错误日志"""
        if self.logger:
            self.logger.error(message)
    
    def get_results(self) -> List[Dict[str, Any]]:
        """获取扫描结果（字典格式）"""
        return [result.to_dict() for result in self.results]
