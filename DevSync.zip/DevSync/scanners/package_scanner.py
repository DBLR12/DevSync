"""包管理器扫描器"""
from typing import List
import json
from .base_scanner import BaseScanner, ScanResult


class PackageScanner(BaseScanner):
    """包管理器扫描器"""
    
    def scan(self) -> List[ScanResult]:
        """扫描所有包管理器"""
        self.log_info("正在扫描包管理器...")
        self.results = []
        
        # 扫描 Python 包
        self._scan_pip_packages()
        
        # 扫描 Node.js 全局包
        self._scan_npm_packages()
        
        # 扫描 Chocolatey 包（Windows）
        self._scan_chocolatey_packages()
        
        self.log_info(f"包管理器扫描完成，共检测到 {len(self.results)} 个包")
        return self.results
    
    def _scan_pip_packages(self):
        """扫描 pip 包"""
        if not self._check_command_exists("pip"):
            return
        
        self.log_info("  扫描 Python pip 包...")
        output = self._run_command("pip list --format=json")
        
        if output:
            try:
                packages = json.loads(output)
                for pkg in packages:
                    result = ScanResult(
                        name=pkg["name"],
                        version=pkg["version"],
                        item_type="package",
                        install_method="auto",
                        detection_source="pip",
                        auto_install_command=f"pip install {pkg['name']}=={pkg['version']}",
                        verify_command=f"pip show {pkg['name']}",
                        priority=3,
                        package_manager="pip"
                    )
                    self.results.append(result)
                
                self.log_info(f"    检测到 {len(packages)} 个 pip 包")
            except json.JSONDecodeError:
                self.log_warning("    pip 包列表解析失败")
    
    def _scan_npm_packages(self):
        """扫描 npm 全局包"""
        if not self._check_command_exists("npm"):
            return
        
        self.log_info("  扫描 Node.js npm 全局包...")
        output = self._run_command("npm list -g --depth=0 --json")
        
        if output:
            try:
                data = json.loads(output)
                dependencies = data.get("dependencies", {})
                
                for pkg_name, pkg_info in dependencies.items():
                    version = pkg_info.get("version", "unknown")
                    result = ScanResult(
                        name=pkg_name,
                        version=version,
                        item_type="package",
                        install_method="auto",
                        detection_source="npm",
                        auto_install_command=f"npm install -g {pkg_name}@{version}",
                        verify_command=f"npm list -g {pkg_name}",
                        priority=3,
                        package_manager="npm",
                        scope="global"
                    )
                    self.results.append(result)
                
                self.log_info(f"    检测到 {len(dependencies)} 个 npm 全局包")
            except json.JSONDecodeError:
                self.log_warning("    npm 包列表解析失败")
    
    def _scan_chocolatey_packages(self):
        """扫描 Chocolatey 包（Windows）"""
        if not self._check_command_exists("choco"):
            return
        
        self.log_info("  扫描 Chocolatey 包...")
        output = self._run_command("choco list --local-only")
        
        if output:
            lines = output.split('\n')
            count = 0
            
            for line in lines:
                # 格式: packagename version
                parts = line.split()
                if len(parts) >= 2 and not line.startswith('Chocolatey'):
                    pkg_name = parts[0]
                    version = parts[1]
                    
                    result = ScanResult(
                        name=pkg_name,
                        version=version,
                        item_type="package",
                        install_method="auto",
                        detection_source="chocolatey",
                        auto_install_command=f"choco install {pkg_name} --version={version} -y",
                        verify_command=f"choco list --local-only {pkg_name}",
                        priority=3,
                        package_manager="chocolatey"
                    )
                    self.results.append(result)
                    count += 1
            
            self.log_info(f"    检测到 {count} 个 Chocolatey 包")
