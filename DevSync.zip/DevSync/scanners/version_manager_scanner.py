"""版本管理工具扫描器"""
from typing import List
import re
from .base_scanner import BaseScanner, ScanResult


class VersionManagerScanner(BaseScanner):
    """版本管理工具扫描器"""
    
    # 支持的版本管理工具
    VERSION_MANAGERS = {
        "nvm": {
            "command": "nvm",
            "version_flag": "-v",
            "list_command": "nvm list",
            "description": "Node.js 版本管理工具",
            "download_url": "https://github.com/coreybutler/nvm-windows/releases",
            "priority": 4,
            "manages": "Node.js"
        },
        "pyenv": {
            "command": "pyenv",
            "version_flag": "--version",
            "list_command": "pyenv versions",
            "description": "Python 版本管理工具",
            "download_url": "https://github.com/pyenv/pyenv",
            "priority": 4,
            "manages": "Python"
        },
        "rbenv": {
            "command": "rbenv",
            "version_flag": "--version",
            "list_command": "rbenv versions",
            "description": "Ruby 版本管理工具",
            "download_url": "https://github.com/rbenv/rbenv",
            "priority": 3,
            "manages": "Ruby"
        },
        "rustup": {
            "command": "rustup",
            "version_flag": "--version",
            "list_command": "rustup toolchain list",
            "description": "Rust 工具链管理器",
            "download_url": "https://rustup.rs/",
            "priority": 4,
            "manages": "Rust"
        },
        "sdkman": {
            "command": "sdk",
            "version_flag": "version",
            "list_command": "sdk list java",
            "description": "Java SDK 管理工具",
            "download_url": "https://sdkman.io/",
            "priority": 3,
            "manages": "Java"
        }
    }
    
    def scan(self) -> List[ScanResult]:
        """扫描版本管理工具"""
        self.log_info("正在扫描版本管理工具...")
        self.results = []
        
        for tool_name, config in self.VERSION_MANAGERS.items():
            # 特殊处理 nvm：即使命令不可用，也尝试从目录扫描
            if tool_name == "nvm":
                self._scan_nvm_tool()
            elif self._check_command_exists(config["command"]):
                # 其他工具：只有命令存在时才扫描
                if tool_name == "nvm":
                    version = self._run_command(f"nvm {config['version_flag']}", use_cmd=True)
                else:
                    version = self._get_version(config["command"], config["version_flag"])
                
                if version:
                    self.log_info(f"  ✓ 检测到 {tool_name}: {version}")
                    
                    # 添加版本管理工具本身
                    result = ScanResult(
                        name=tool_name.upper(),
                        version=version,
                        item_type="tool",
                        install_method="manual",
                        detection_source="PATH",
                        download_url=config["download_url"],
                        install_guide=f"{config['description']}，用于管理 {config['manages']} 版本",
                        verify_command=f"{config['command']} {config['version_flag']}",
                        priority=config["priority"],
                        tool_category="version_manager",
                        manages=config["manages"]
                    )
                    self.results.append(result)
                    
                    # 获取该工具管理的所有版本
                    managed_versions = self._get_managed_versions(tool_name, config)
                    if managed_versions:
                        self.log_info(f"    检测到 {len(managed_versions)} 个 {config['manages']} 版本")
                        for ver_info in managed_versions:
                            self.results.append(ver_info)
        
        self.log_info(f"版本管理工具扫描完成，共检测到 {len(self.results)} 项")
        return self.results
    
    def _scan_nvm_tool(self):
        """专门扫描 nvm（通过目录方式）"""
        import os
        
        # 获取 nvm 路径
        nvm_home = os.environ.get('NVM_HOME')
        
        if not nvm_home:
            # 尝试默认路径
            possible_paths = [
                os.path.expanduser('~\\AppData\\Roaming\\nvm'),
                'C:\\Program Files\\nvm',
                'C:\\nvm'
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    nvm_home = path
                    break
        
        if nvm_home and os.path.exists(nvm_home):
            self.log_info(f"  ✓ 检测到 nvm (从目录)")
            
            # 尝试获取 nvm 版本（从 settings.txt 或其他方式）
            version = "已安装"  # 默认值
            
            # 添加 nvm 工具本身
            result = ScanResult(
                name="NVM",
                version=version,
                item_type="tool",
                install_method="manual",
                detection_source="directory",
                download_url="https://github.com/coreybutler/nvm-windows/releases",
                install_guide="Node.js 版本管理工具，用于管理 Node.js 版本",
                verify_command="nvm version",
                priority=4,
                tool_category="version_manager",
                manages="Node.js"
            )
            self.results.append(result)
            
            # 扫描管理的版本
            managed_versions = self._scan_nvm_from_directory()
            if managed_versions:
                self.log_info(f"    检测到 {len(managed_versions)} 个 Node.js 版本")
                for ver_info in managed_versions:
                    self.results.append(ver_info)
    
    def _get_managed_versions(self, tool_name: str, config: dict) -> List[ScanResult]:
        """获取版本管理工具管理的所有版本"""
        versions = []
        
        if tool_name == "nvm":
            versions = self._scan_nvm_versions()
        elif tool_name == "pyenv":
            versions = self._scan_pyenv_versions()
        elif tool_name == "rbenv":
            versions = self._scan_rbenv_versions()
        elif tool_name == "rustup":
            versions = self._scan_rustup_versions()
        
        return versions
    
    def _scan_nvm_versions(self) -> List[ScanResult]:
        """扫描 nvm 管理的 Node.js 版本"""
        versions = []
        
        # 方法1: 尝试通过命令获取（可能失败）
        output = self._run_command("nvm list", use_cmd=True)
        
        if output and 'Terminal Only' not in output:
            # 命令成功，解析输出
            lines = output.split('\n')
            for line in lines:
                match = re.search(r'[\s*]*(\d+\.\d+\.\d+)', line)
                if match:
                    version = match.group(1)
                    is_current = '*' in line or 'Currently using' in line
                    
                    result = ScanResult(
                        name=f"Node.js (nvm)",
                        version=version,
                        item_type="language",
                        install_method="semi_auto",
                        detection_source="nvm",
                        auto_install_command=f"nvm install {version}",
                        verify_command=f"nvm use {version} && node --version",
                        priority=4 if is_current else 3,
                        notes=f"{'当前使用版本' if is_current else '已安装版本'}",
                        managed_by="nvm",
                        is_current=is_current
                    )
                    versions.append(result)
        else:
            # 方法2: 读取 nvm 安装目录
            versions = self._scan_nvm_from_directory()
        
        return versions
    
    def _scan_nvm_from_directory(self) -> List[ScanResult]:
        """从 nvm 安装目录扫描版本"""
        versions = []
        
        # 尝试从环境变量获取 nvm 路径
        import os
        nvm_home = os.environ.get('NVM_HOME')
        nvm_symlink = os.environ.get('NVM_SYMLINK')
        
        if not nvm_home:
            # 尝试默认路径
            possible_paths = [
                os.path.expanduser('~\\AppData\\Roaming\\nvm'),
                'C:\\Program Files\\nvm',
                'C:\\nvm'
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    nvm_home = path
                    break
        
        if nvm_home and os.path.exists(nvm_home):
            self.log_info(f"    从目录扫描: {nvm_home}")
            
            # 扫描 nvm 目录下的所有 Node.js 版本
            from pathlib import Path
            nvm_path = Path(nvm_home)
            
            # 检查当前使用的版本
            current_version = None
            if nvm_symlink and os.path.exists(nvm_symlink):
                # 读取符号链接指向的版本
                try:
                    if os.path.islink(nvm_symlink):
                        target = os.readlink(nvm_symlink)
                        match = re.search(r'v(\d+\.\d+\.\d+)', target)
                        if match:
                            current_version = match.group(1)
                except:
                    pass
            
            # 如果没有符号链接，尝试检测当前 node 版本
            if not current_version:
                node_version = self._run_command("node --version")
                if node_version:
                    current_version = node_version.lstrip('v')
            
            # 扫描所有已安装的版本
            for item in nvm_path.iterdir():
                if item.is_dir() and item.name.startswith('v'):
                    # 提取版本号
                    match = re.search(r'v(\d+\.\d+\.\d+)', item.name)
                    if match:
                        version = match.group(1)
                        is_current = (version == current_version)
                        
                        result = ScanResult(
                            name=f"Node.js (nvm)",
                            version=version,
                            item_type="language",
                            install_method="semi_auto",
                            detection_source="nvm_directory",
                            auto_install_command=f"nvm install {version}",
                            verify_command=f"nvm use {version} && node --version",
                            priority=4 if is_current else 3,
                            notes=f"{'当前使用版本' if is_current else '已安装版本'}",
                            managed_by="nvm",
                            is_current=is_current
                        )
                        versions.append(result)
            
            self.log_info(f"    从目录检测到 {len(versions)} 个版本")
        
        return versions
    
    def _scan_pyenv_versions(self) -> List[ScanResult]:
        """扫描 pyenv 管理的 Python 版本"""
        versions = []
        output = self._run_command("pyenv versions")
        
        if output:
            lines = output.split('\n')
            
            for line in lines:
                # 匹配版本号，例如: "* 3.11.5 (set by ...)"
                match = re.search(r'[\s*]*(\d+\.\d+\.\d+)', line)
                if match:
                    version = match.group(1)
                    is_current = '*' in line
                    
                    result = ScanResult(
                        name=f"Python (pyenv)",
                        version=version,
                        item_type="language",
                        install_method="semi_auto",
                        detection_source="pyenv",
                        auto_install_command=f"pyenv install {version}",
                        verify_command=f"pyenv shell {version} && python --version",
                        priority=4 if is_current else 3,
                        notes=f"{'当前使用版本' if is_current else '已安装版本'}",
                        managed_by="pyenv",
                        is_current=is_current
                    )
                    versions.append(result)
        
        return versions
    
    def _scan_rbenv_versions(self) -> List[ScanResult]:
        """扫描 rbenv 管理的 Ruby 版本"""
        versions = []
        output = self._run_command("rbenv versions")
        
        if output:
            lines = output.split('\n')
            
            for line in lines:
                match = re.search(r'[\s*]*(\d+\.\d+\.\d+)', line)
                if match:
                    version = match.group(1)
                    is_current = '*' in line
                    
                    result = ScanResult(
                        name=f"Ruby (rbenv)",
                        version=version,
                        item_type="language",
                        install_method="semi_auto",
                        detection_source="rbenv",
                        auto_install_command=f"rbenv install {version}",
                        verify_command=f"rbenv shell {version} && ruby --version",
                        priority=3,
                        notes=f"{'当前使用版本' if is_current else '已安装版本'}",
                        managed_by="rbenv",
                        is_current=is_current
                    )
                    versions.append(result)
        
        return versions
    
    def _scan_rustup_versions(self) -> List[ScanResult]:
        """扫描 rustup 管理的 Rust 工具链"""
        versions = []
        output = self._run_command("rustup toolchain list")
        
        if output:
            lines = output.split('\n')
            
            for line in lines:
                # 匹配工具链，例如: "stable-x86_64-pc-windows-msvc (default)"
                if line.strip():
                    is_default = '(default)' in line
                    toolchain = line.replace('(default)', '').strip()
                    
                    result = ScanResult(
                        name=f"Rust (rustup)",
                        version=toolchain,
                        item_type="language",
                        install_method="semi_auto",
                        detection_source="rustup",
                        auto_install_command=f"rustup toolchain install {toolchain}",
                        verify_command=f"rustup default {toolchain} && rustc --version",
                        priority=3,
                        notes=f"{'默认工具链' if is_default else '已安装工具链'}",
                        managed_by="rustup",
                        is_current=is_default
                    )
                    versions.append(result)
        
        return versions
