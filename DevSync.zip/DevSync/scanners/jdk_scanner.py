"""JDK 多版本扫描器"""
import re
import os
from pathlib import Path
from typing import List
from .base_scanner import BaseScanner, ScanResult


class JDKScanner(BaseScanner):
    """JDK 多版本扫描器"""
    
    def scan(self) -> List[ScanResult]:
        """扫描所有已安装的 JDK 版本"""
        self.log_info("正在扫描 JDK 安装...")
        self.results = []
        
        # 获取所有 JDK 安装
        jdk_installations = self._find_all_jdks()
        
        if not jdk_installations:
            self.log_info("  未检测到 JDK 安装")
            return self.results
        
        # 获取当前使用的 JDK（通过 JAVA_HOME）
        current_java_home = os.environ.get('JAVA_HOME', '').lower()
        
        self.log_info(f"  检测到 {len(jdk_installations)} 个 JDK 安装")
        
        for jdk_info in jdk_installations:
            is_current = (current_java_home and 
                         jdk_info['path'].lower() == current_java_home)
            
            result = ScanResult(
                name="Java JDK",
                version=jdk_info['version'],
                item_type="language",
                install_method="manual",
                detection_source="directory_scan",
                download_url="https://www.oracle.com/java/technologies/downloads/",
                install_guide=f"JDK {jdk_info['version']} 安装在 {jdk_info['path']}",
                verify_command=f'"{jdk_info["java_exe"]}" -version',
                priority=5 if is_current else 4,
                notes=f"{'当前使用版本 (JAVA_HOME)' if is_current else '已安装版本'}",
                path=jdk_info['path'],
                is_current=is_current
            )
            
            self.results.append(result)
            
            if is_current:
                self.log_info(f"    ✓ JDK {jdk_info['version']} ★ (当前)")
            else:
                self.log_info(f"    ✓ JDK {jdk_info['version']}")
        
        self.log_info(f"JDK 扫描完成，共检测到 {len(self.results)} 个版本")
        return self.results
    
    def _find_all_jdks(self) -> List[dict]:
        """查找所有 JDK 安装"""
        jdk_installations = []
        
        # 1. 从 JAVA_HOME 开始
        java_home = os.environ.get('JAVA_HOME')
        if java_home and os.path.exists(java_home):
            jdk_info = self._get_jdk_info(java_home)
            if jdk_info:
                jdk_installations.append(jdk_info)
        
        # 2. 搜索常见的 JDK 安装目录
        search_paths = self._get_search_paths()
        
        for search_path in search_paths:
            if not os.path.exists(search_path):
                continue
            
            try:
                path_obj = Path(search_path)
                
                # 检查目录本身是否是 JDK
                jdk_info = self._get_jdk_info(search_path)
                if jdk_info and not self._is_duplicate(jdk_info, jdk_installations):
                    jdk_installations.append(jdk_info)
                
                # 检查子目录
                for item in path_obj.iterdir():
                    if item.is_dir():
                        jdk_info = self._get_jdk_info(str(item))
                        if jdk_info and not self._is_duplicate(jdk_info, jdk_installations):
                            jdk_installations.append(jdk_info)
            except (PermissionError, OSError):
                continue
        
        return jdk_installations
    
    def _get_search_paths(self) -> List[str]:
        """获取要搜索的路径列表"""
        paths = []
        
        # 从 JAVA_HOME 推断其他可能的路径
        java_home = os.environ.get('JAVA_HOME')
        if java_home:
            parent = str(Path(java_home).parent)
            paths.append(parent)
        
        # 常见的 JDK 安装位置
        drives = ['C:', 'D:', 'E:', 'F:']
        for drive in drives:
            if os.path.exists(drive):
                # 根目录下的 Java 相关目录
                try:
                    for item in Path(drive + '\\').iterdir():
                        if item.is_dir():
                            name_lower = item.name.lower()
                            if any(keyword in name_lower for keyword in ['java', 'jdk', 'openjdk']):
                                paths.append(str(item))
                except (PermissionError, OSError):
                    pass
        
        # Program Files
        paths.extend([
            'C:\\Program Files\\Java',
            'C:\\Program Files (x86)\\Java',
            'D:\\Program Files\\Java',
        ])
        
        # 用户目录
        paths.extend([
            os.path.expanduser('~\\.jdks'),
            os.path.expanduser('~\\.sdkman\\candidates\\java'),
        ])
        
        return paths
    
    def _get_jdk_info(self, path: str) -> dict:
        """获取指定路径的 JDK 信息"""
        java_exe = Path(path) / "bin" / "java.exe"
        
        if not java_exe.exists():
            return None
        
        # 获取版本信息
        version = self._get_jdk_version(str(java_exe))
        
        if version:
            return {
                'path': path,
                'version': version,
                'java_exe': str(java_exe)
            }
        
        return None
    
    def _get_jdk_version(self, java_exe: str) -> str:
        """获取 JDK 版本"""
        output = self._run_command(f'"{java_exe}" -version', capture_stderr=True)
        
        if output:
            # 尝试多种版本格式
            patterns = [
                r'version "([^"]+)"',  # java version "1.8.0_431"
                r'openjdk version "([^"]+)"',  # openjdk version "23.0.2"
                r'version ([0-9]+\.[0-9]+\.[0-9]+)',  # version 17.0.14
                r'version "([0-9]+)"',  # version "21"
            ]
            
            for pattern in patterns:
                match = re.search(pattern, output)
                if match:
                    return match.group(1)
        
        return None
    
    def _is_duplicate(self, jdk_info: dict, existing_list: List[dict]) -> bool:
        """检查是否是重复的 JDK"""
        for existing in existing_list:
            if existing['path'].lower() == jdk_info['path'].lower():
                return True
        return False
