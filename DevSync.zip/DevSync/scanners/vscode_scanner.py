"""VSCode 插件扫描器"""
from typing import List
from pathlib import Path
import os
import json
from .base_scanner import BaseScanner, ScanResult


class VSCodeScanner(BaseScanner):
    """VSCode 插件扫描器"""
    
    def __init__(self, logger=None):
        super().__init__(logger)
        # VSCode 扩展目录
        self.extensions_dir = Path(os.path.expanduser("~")) / ".vscode" / "extensions"
    
    def scan(self) -> List[ScanResult]:
        """扫描 VSCode 插件"""
        self.log_info("正在扫描 VSCode 插件...")
        self.results = []
        
        if not self.extensions_dir.exists():
            self.log_warning("  未找到 VSCode 扩展目录")
            return self.results
        
        # 方法1: 通过 code 命令获取插件列表
        if self._check_command_exists("code"):
            self._scan_via_command()
        else:
            # 方法2: 扫描扩展目录
            self._scan_via_directory()
        
        self.log_info(f"VSCode 插件扫描完成，共检测到 {len(self.results)} 个")
        return self.results
    
    def _scan_via_command(self):
        """通过 code 命令扫描插件"""
        output = self._run_command("code --list-extensions --show-versions")
        
        if output:
            lines = output.split('\n')
            for line in lines:
                if '@' in line:
                    # 格式: publisher.extension@version
                    parts = line.split('@')
                    if len(parts) == 2:
                        extension_id = parts[0]
                        version = parts[1]
                        
                        result = ScanResult(
                            name=extension_id,
                            version=version,
                            item_type="ide_plugin",
                            install_method="auto",
                            detection_source="vscode_cli",
                            auto_install_command=f"code --install-extension {extension_id}",
                            verify_command=f"code --list-extensions | findstr {extension_id}",
                            priority=4,
                            ide="vscode"
                        )
                        self.results.append(result)
    
    def _scan_via_directory(self):
        """通过扫描目录获取插件"""
        for ext_dir in self.extensions_dir.iterdir():
            if ext_dir.is_dir():
                # 目录名格式: publisher.extension-version
                dir_name = ext_dir.name
                
                # 尝试解析版本号
                if '-' in dir_name:
                    parts = dir_name.rsplit('-', 1)
                    extension_id = parts[0]
                    version = parts[1] if len(parts) > 1 else "unknown"
                    
                    # 尝试从 package.json 读取更详细信息
                    package_json = ext_dir / "package.json"
                    display_name = extension_id
                    
                    if package_json.exists():
                        try:
                            with open(package_json, 'r', encoding='utf-8') as f:
                                data = json.load(f)
                                display_name = data.get("displayName", extension_id)
                                version = data.get("version", version)
                        except:
                            pass
                    
                    result = ScanResult(
                        name=extension_id,
                        version=version,
                        item_type="ide_plugin",
                        install_method="auto",
                        detection_source="vscode_directory",
                        auto_install_command=f"code --install-extension {extension_id}",
                        verify_command=f"code --list-extensions | findstr {extension_id}",
                        priority=4,
                        ide="vscode",
                        display_name=display_name
                    )
                    self.results.append(result)
