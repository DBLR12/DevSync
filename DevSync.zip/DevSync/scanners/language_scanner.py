"""编程语言环境扫描器"""
from typing import List
from .base_scanner import BaseScanner, ScanResult


class LanguageScanner(BaseScanner):
    """编程语言环境扫描器"""
    
    # 支持的语言配置
    LANGUAGES = {
        "python": {
            "command": "python",
            "version_flag": "--version",
            "download_url": "https://www.python.org/downloads/",
            "install_guide": "下载安装包，安装时勾选 'Add Python to PATH'",
            "verify_command": "python --version",
            "priority": 5
        },
        "python3": {
            "command": "python3",
            "version_flag": "--version",
            "download_url": "https://www.python.org/downloads/",
            "install_guide": "下载安装包，安装时勾选 'Add Python to PATH'",
            "verify_command": "python3 --version",
            "priority": 5
        },
        "node": {
            "command": "node",
            "version_flag": "--version",
            "download_url": "https://nodejs.org/",
            "install_guide": "推荐下载 LTS 版本",
            "verify_command": "node --version",
            "priority": 5
        },
        "java": {
            "command": "java",
            "version_flag": "-version",
            "download_url": "https://www.oracle.com/java/technologies/downloads/",
            "install_guide": "下载 JDK 并配置 JAVA_HOME 环境变量",
            "verify_command": "java -version",
            "priority": 4
        },
        "javac": {
            "command": "javac",
            "version_flag": "-version",
            "download_url": "https://www.oracle.com/java/technologies/downloads/",
            "install_guide": "JDK 编译器，随 JDK 一起安装",
            "verify_command": "javac -version",
            "priority": 4
        },
        "maven": {
            "command": "mvn",
            "version_flag": "--version",
            "download_url": "https://maven.apache.org/download.cgi",
            "install_guide": "下载解压后配置 M2_HOME 和 PATH 环境变量",
            "verify_command": "mvn --version",
            "priority": 4
        },
        "gradle": {
            "command": "gradle",
            "version_flag": "--version",
            "download_url": "https://gradle.org/install/",
            "install_guide": "下载解压后配置 PATH 环境变量",
            "verify_command": "gradle --version",
            "priority": 3
        },
        "dotnet": {
            "command": "dotnet",
            "version_flag": "--version",
            "download_url": "https://dotnet.microsoft.com/download",
            "install_guide": "下载 .NET SDK 安装包",
            "verify_command": "dotnet --version",
            "priority": 4
        },
        "csc": {
            "command": "csc",
            "version_flag": "/version",
            "download_url": "https://dotnet.microsoft.com/download",
            "install_guide": "C# 编译器，随 .NET SDK 或 Visual Studio 安装",
            "verify_command": "csc /version",
            "priority": 3
        },
        "go": {
            "command": "go",
            "version_flag": "version",
            "download_url": "https://go.dev/dl/",
            "install_guide": "下载安装包并配置 GOPATH",
            "verify_command": "go version",
            "priority": 4
        },
        "rust": {
            "command": "rustc",
            "version_flag": "--version",
            "download_url": "https://www.rust-lang.org/tools/install",
            "install_guide": "推荐使用 rustup 安装: https://rustup.rs/",
            "verify_command": "rustc --version",
            "priority": 4
        },
        "ruby": {
            "command": "ruby",
            "version_flag": "--version",
            "download_url": "https://www.ruby-lang.org/en/downloads/",
            "install_guide": "Windows 推荐使用 RubyInstaller",
            "verify_command": "ruby --version",
            "priority": 3
        },
        "php": {
            "command": "php",
            "version_flag": "--version",
            "download_url": "https://www.php.net/downloads",
            "install_guide": "下载并配置到 PATH",
            "verify_command": "php --version",
            "priority": 3
        },
        "gcc": {
            "command": "gcc",
            "version_flag": "--version",
            "download_url": "https://www.mingw-w64.org/",
            "install_guide": "Windows 推荐安装 MinGW-w64",
            "verify_command": "gcc --version",
            "priority": 3
        },
        "git": {
            "command": "git",
            "version_flag": "--version",
            "download_url": "https://git-scm.com/downloads",
            "install_guide": "下载安装包，推荐默认配置",
            "verify_command": "git --version",
            "priority": 5
        },
        "npm": {
            "command": "npm",
            "version_flag": "--version",
            "download_url": "https://nodejs.org/",
            "install_guide": "随 Node.js 一起安装",
            "verify_command": "npm --version",
            "priority": 5
        },
        "yarn": {
            "command": "yarn",
            "version_flag": "--version",
            "download_url": "https://yarnpkg.com/getting-started/install",
            "install_guide": "npm install -g yarn 或下载安装包",
            "verify_command": "yarn --version",
            "priority": 4
        },
        "pnpm": {
            "command": "pnpm",
            "version_flag": "--version",
            "download_url": "https://pnpm.io/installation",
            "install_guide": "npm install -g pnpm",
            "verify_command": "pnpm --version",
            "priority": 4
        },
        "pip": {
            "command": "pip",
            "version_flag": "--version",
            "download_url": "https://pip.pypa.io/en/stable/installation/",
            "install_guide": "随 Python 一起安装",
            "verify_command": "pip --version",
            "priority": 5
        },
        "pip3": {
            "command": "pip3",
            "version_flag": "--version",
            "download_url": "https://pip.pypa.io/en/stable/installation/",
            "install_guide": "随 Python3 一起安装",
            "verify_command": "pip3 --version",
            "priority": 5
        },
        "docker": {
            "command": "docker",
            "version_flag": "--version",
            "download_url": "https://www.docker.com/products/docker-desktop",
            "install_guide": "下载 Docker Desktop 安装",
            "verify_command": "docker --version",
            "priority": 4
        },
        "docker-compose": {
            "command": "docker-compose",
            "version_flag": "--version",
            "download_url": "https://docs.docker.com/compose/install/",
            "install_guide": "随 Docker Desktop 一起安装",
            "verify_command": "docker-compose --version",
            "priority": 3
        },
        "kubectl": {
            "command": "kubectl",
            "version_flag": "version --client",
            "download_url": "https://kubernetes.io/docs/tasks/tools/",
            "install_guide": "下载 kubectl 二进制文件",
            "verify_command": "kubectl version --client",
            "priority": 3
        },
        "terraform": {
            "command": "terraform",
            "version_flag": "--version",
            "download_url": "https://www.terraform.io/downloads",
            "install_guide": "下载解压后添加到 PATH",
            "verify_command": "terraform --version",
            "priority": 3
        },
        "ansible": {
            "command": "ansible",
            "version_flag": "--version",
            "download_url": "https://docs.ansible.com/ansible/latest/installation_guide/",
            "install_guide": "pip install ansible",
            "verify_command": "ansible --version",
            "priority": 3
        },
        "make": {
            "command": "make",
            "version_flag": "--version",
            "download_url": "http://gnuwin32.sourceforge.net/packages/make.htm",
            "install_guide": "Windows 需要安装 GnuWin32 或 MinGW",
            "verify_command": "make --version",
            "priority": 3
        },
        "cmake": {
            "command": "cmake",
            "version_flag": "--version",
            "download_url": "https://cmake.org/download/",
            "install_guide": "下载安装包",
            "verify_command": "cmake --version",
            "priority": 3
        },
        # 前端框架和工具
        "vue": {
            "command": "vue",
            "version_flag": "--version",
            "download_url": "https://cli.vuejs.org/",
            "install_guide": "npm install -g @vue/cli",
            "verify_command": "vue --version",
            "priority": 4
        },
        "vite": {
            "command": "vite",
            "version_flag": "--version",
            "download_url": "https://vitejs.dev/",
            "install_guide": "npm install -g vite",
            "verify_command": "vite --version",
            "priority": 3
        },
        "ng": {
            "command": "ng",
            "version_flag": "version",
            "download_url": "https://angular.io/cli",
            "install_guide": "npm install -g @angular/cli",
            "verify_command": "ng version",
            "priority": 3
        },
        "create-react-app": {
            "command": "create-react-app",
            "version_flag": "--version",
            "download_url": "https://create-react-app.dev/",
            "install_guide": "npm install -g create-react-app",
            "verify_command": "create-react-app --version",
            "priority": 3
        },
        "next": {
            "command": "next",
            "version_flag": "--version",
            "download_url": "https://nextjs.org/",
            "install_guide": "npm install -g next",
            "verify_command": "next --version",
            "priority": 3
        },
        # TypeScript 和 Babel
        "tsc": {
            "command": "tsc",
            "version_flag": "--version",
            "download_url": "https://www.typescriptlang.org/",
            "install_guide": "npm install -g typescript",
            "verify_command": "tsc --version",
            "priority": 4
        },
        "babel": {
            "command": "babel",
            "version_flag": "--version",
            "download_url": "https://babeljs.io/",
            "install_guide": "npm install -g @babel/cli",
            "verify_command": "babel --version",
            "priority": 3
        },
        # 打包工具
        "webpack": {
            "command": "webpack",
            "version_flag": "--version",
            "download_url": "https://webpack.js.org/",
            "install_guide": "npm install -g webpack webpack-cli",
            "verify_command": "webpack --version",
            "priority": 3
        },
        "rollup": {
            "command": "rollup",
            "version_flag": "--version",
            "download_url": "https://rollupjs.org/",
            "install_guide": "npm install -g rollup",
            "verify_command": "rollup --version",
            "priority": 3
        },
        "parcel": {
            "command": "parcel",
            "version_flag": "--version",
            "download_url": "https://parceljs.org/",
            "install_guide": "npm install -g parcel",
            "verify_command": "parcel --version",
            "priority": 3
        },
        # 代码质量工具
        "eslint": {
            "command": "eslint",
            "version_flag": "--version",
            "download_url": "https://eslint.org/",
            "install_guide": "npm install -g eslint",
            "verify_command": "eslint --version",
            "priority": 3
        },
        "prettier": {
            "command": "prettier",
            "version_flag": "--version",
            "download_url": "https://prettier.io/",
            "install_guide": "npm install -g prettier",
            "verify_command": "prettier --version",
            "priority": 3
        },
        # 测试框架
        "jest": {
            "command": "jest",
            "version_flag": "--version",
            "download_url": "https://jestjs.io/",
            "install_guide": "npm install -g jest",
            "verify_command": "jest --version",
            "priority": 3
        },
        "mocha": {
            "command": "mocha",
            "version_flag": "--version",
            "download_url": "https://mochajs.org/",
            "install_guide": "npm install -g mocha",
            "verify_command": "mocha --version",
            "priority": 3
        },
        "pytest": {
            "command": "pytest",
            "version_flag": "--version",
            "download_url": "https://pytest.org/",
            "install_guide": "pip install pytest",
            "verify_command": "pytest --version",
            "priority": 3
        },
        # 数据库工具
        "mysql": {
            "command": "mysql",
            "version_flag": "--version",
            "download_url": "https://dev.mysql.com/downloads/",
            "install_guide": "下载 MySQL 安装包",
            "verify_command": "mysql --version",
            "priority": 3
        },
        "psql": {
            "command": "psql",
            "version_flag": "--version",
            "download_url": "https://www.postgresql.org/download/",
            "install_guide": "下载 PostgreSQL 安装包",
            "verify_command": "psql --version",
            "priority": 3
        },
        "mongo": {
            "command": "mongo",
            "version_flag": "--version",
            "download_url": "https://www.mongodb.com/try/download/community",
            "install_guide": "下载 MongoDB 安装包",
            "verify_command": "mongo --version",
            "priority": 3
        },
        "mongosh": {
            "command": "mongosh",
            "version_flag": "--version",
            "download_url": "https://www.mongodb.com/try/download/shell",
            "install_guide": "下载 MongoDB Shell",
            "verify_command": "mongosh --version",
            "priority": 3
        },
        "redis-cli": {
            "command": "redis-cli",
            "version_flag": "--version",
            "download_url": "https://redis.io/download",
            "install_guide": "下载 Redis 安装包",
            "verify_command": "redis-cli --version",
            "priority": 3
        },
        "sqlcmd": {
            "command": "sqlcmd",
            "version_flag": "-?",
            "download_url": "https://docs.microsoft.com/en-us/sql/tools/sqlcmd-utility",
            "install_guide": "SQL Server 命令行工具，随 SQL Server 或 SQL Server Management Studio 安装",
            "verify_command": "sqlcmd -?",
            "priority": 3
        },
        "sqlplus": {
            "command": "sqlplus",
            "version_flag": "-version",
            "download_url": "https://www.oracle.com/database/technologies/instant-client/downloads.html",
            "install_guide": "Oracle SQL*Plus，随 Oracle Database 或 Instant Client 安装",
            "verify_command": "sqlplus -version",
            "priority": 3
        },
        "sqlite3": {
            "command": "sqlite3",
            "version_flag": "--version",
            "download_url": "https://www.sqlite.org/download.html",
            "install_guide": "下载 SQLite 命令行工具",
            "verify_command": "sqlite3 --version",
            "priority": 3
        },
        "mariadb": {
            "command": "mariadb",
            "version_flag": "--version",
            "download_url": "https://mariadb.org/download/",
            "install_guide": "下载 MariaDB 安装包",
            "verify_command": "mariadb --version",
            "priority": 3
        },
        "influx": {
            "command": "influx",
            "version_flag": "version",
            "download_url": "https://www.influxdata.com/downloads/",
            "install_guide": "下载 InfluxDB CLI",
            "verify_command": "influx version",
            "priority": 2
        },
        "couchdb": {
            "command": "couchdb",
            "version_flag": "-V",
            "download_url": "https://couchdb.apache.org/",
            "install_guide": "下载 CouchDB 安装包",
            "verify_command": "couchdb -V",
            "priority": 2
        },
        "cassandra": {
            "command": "cassandra",
            "version_flag": "-v",
            "download_url": "https://cassandra.apache.org/download/",
            "install_guide": "下载 Apache Cassandra",
            "verify_command": "cassandra -v",
            "priority": 2
        },
        "neo4j": {
            "command": "neo4j",
            "version_flag": "version",
            "download_url": "https://neo4j.com/download/",
            "install_guide": "下载 Neo4j 图数据库",
            "verify_command": "neo4j version",
            "priority": 2
        },
        "elasticsearch": {
            "command": "elasticsearch",
            "version_flag": "--version",
            "download_url": "https://www.elastic.co/downloads/elasticsearch",
            "install_guide": "下载 Elasticsearch",
            "verify_command": "elasticsearch --version",
            "priority": 3
        },
        # 云服务 CLI
        "aws": {
            "command": "aws",
            "version_flag": "--version",
            "download_url": "https://aws.amazon.com/cli/",
            "install_guide": "下载 AWS CLI 安装包",
            "verify_command": "aws --version",
            "priority": 3
        },
        "az": {
            "command": "az",
            "version_flag": "--version",
            "download_url": "https://docs.microsoft.com/en-us/cli/azure/install-azure-cli",
            "install_guide": "下载 Azure CLI 安装包",
            "verify_command": "az --version",
            "priority": 3
        },
        "gcloud": {
            "command": "gcloud",
            "version_flag": "version",
            "download_url": "https://cloud.google.com/sdk/docs/install",
            "install_guide": "下载 Google Cloud SDK",
            "verify_command": "gcloud version",
            "priority": 3
        },
        # 版本控制
        "svn": {
            "command": "svn",
            "version_flag": "--version",
            "download_url": "https://subversion.apache.org/",
            "install_guide": "下载 SVN 客户端",
            "verify_command": "svn --version",
            "priority": 3
        },
        "hg": {
            "command": "hg",
            "version_flag": "--version",
            "download_url": "https://www.mercurial-scm.org/",
            "install_guide": "下载 Mercurial",
            "verify_command": "hg --version",
            "priority": 2
        },
        # 其他编程语言
        "kotlin": {
            "command": "kotlin",
            "version_flag": "-version",
            "download_url": "https://kotlinlang.org/",
            "install_guide": "下载 Kotlin 编译器",
            "verify_command": "kotlin -version",
            "priority": 3
        },
        "scala": {
            "command": "scala",
            "version_flag": "-version",
            "download_url": "https://www.scala-lang.org/download/",
            "install_guide": "下载 Scala 安装包",
            "verify_command": "scala -version",
            "priority": 3
        },
        "perl": {
            "command": "perl",
            "version_flag": "--version",
            "download_url": "https://www.perl.org/get.html",
            "install_guide": "下载 Perl 安装包",
            "verify_command": "perl --version",
            "priority": 2
        },
        "lua": {
            "command": "lua",
            "version_flag": "-v",
            "download_url": "https://www.lua.org/download.html",
            "install_guide": "下载 Lua 安装包",
            "verify_command": "lua -v",
            "priority": 2
        },
        "dart": {
            "command": "dart",
            "version_flag": "--version",
            "download_url": "https://dart.dev/get-dart",
            "install_guide": "下载 Dart SDK",
            "verify_command": "dart --version",
            "priority": 3
        },
        "flutter": {
            "command": "flutter",
            "version_flag": "--version",
            "download_url": "https://flutter.dev/",
            "install_guide": "下载 Flutter SDK",
            "verify_command": "flutter --version",
            "priority": 4
        },
        # 构建和任务运行器
        "gulp": {
            "command": "gulp",
            "version_flag": "--version",
            "download_url": "https://gulpjs.com/",
            "install_guide": "npm install -g gulp-cli",
            "verify_command": "gulp --version",
            "priority": 3
        },
        "grunt": {
            "command": "grunt",
            "version_flag": "--version",
            "download_url": "https://gruntjs.com/",
            "install_guide": "npm install -g grunt-cli",
            "verify_command": "grunt --version",
            "priority": 2
        },
        # 服务器和运行时
        "nginx": {
            "command": "nginx",
            "version_flag": "-v",
            "download_url": "https://nginx.org/en/download.html",
            "install_guide": "下载 Nginx 安装包",
            "verify_command": "nginx -v",
            "priority": 3
        },
        "apache2": {
            "command": "apache2",
            "version_flag": "-v",
            "download_url": "https://httpd.apache.org/download.cgi",
            "install_guide": "下载 Apache 安装包",
            "verify_command": "apache2 -v",
            "priority": 3
        },
        # 包管理器（系统级）
        "chocolatey": {
            "command": "choco",
            "version_flag": "--version",
            "download_url": "https://chocolatey.org/install",
            "install_guide": "Windows 包管理器",
            "verify_command": "choco --version",
            "priority": 3
        },
        "scoop": {
            "command": "scoop",
            "version_flag": "--version",
            "download_url": "https://scoop.sh/",
            "install_guide": "Windows 命令行安装器",
            "verify_command": "scoop --version",
            "priority": 3
        },
        "winget": {
            "command": "winget",
            "version_flag": "--version",
            "download_url": "https://github.com/microsoft/winget-cli",
            "install_guide": "Windows 包管理器（Windows 11 自带）",
            "verify_command": "winget --version",
            "priority": 3
        },
        # 其他常用工具
        "curl": {
            "command": "curl",
            "version_flag": "--version",
            "download_url": "https://curl.se/download.html",
            "install_guide": "下载 curl",
            "verify_command": "curl --version",
            "priority": 4
        },
        "wget": {
            "command": "wget",
            "version_flag": "--version",
            "download_url": "https://www.gnu.org/software/wget/",
            "install_guide": "下载 wget",
            "verify_command": "wget --version",
            "priority": 3
        },
        "ssh": {
            "command": "ssh",
            "version_flag": "-V",
            "download_url": "https://www.openssh.com/",
            "install_guide": "OpenSSH（Windows 10+ 自带）",
            "verify_command": "ssh -V",
            "priority": 4
        },
        "rsync": {
            "command": "rsync",
            "version_flag": "--version",
            "download_url": "https://rsync.samba.org/",
            "install_guide": "文件同步工具",
            "verify_command": "rsync --version",
            "priority": 2
        },
        "7z": {
            "command": "7z",
            "version_flag": "--help",
            "download_url": "https://www.7-zip.org/",
            "install_guide": "下载 7-Zip",
            "verify_command": "7z --help",
            "priority": 3
        }
    }
    
    def scan(self) -> List[ScanResult]:
        """扫描编程语言环境"""
        self.log_info("正在扫描编程语言环境...")
        self.results = []
        
        for lang_name, config in self.LANGUAGES.items():
            # 特殊处理某些命令
            if lang_name in ["java", "javac"]:
                version = self._get_java_version(config["command"], config["version_flag"])
            elif lang_name == "maven":
                version = self._get_maven_version()
            elif lang_name == "csc":
                version = self._get_csc_version()
            else:
                version = self._get_version(config["command"], config["version_flag"])
            
            if version:
                # 检测到语言环境
                self.log_info(f"  ✓ 检测到 {lang_name}: {version}")
                
                result = ScanResult(
                    name=lang_name.capitalize(),
                    version=version,
                    item_type="language",
                    install_method="manual",  # 语言环境通常需要手动安装
                    detection_source="PATH",
                    download_url=config["download_url"],
                    install_guide=config["install_guide"],
                    verify_command=config["verify_command"],
                    priority=config["priority"],
                    command=config["command"]
                )
                
                self.results.append(result)
        
        self.log_info(f"编程语言扫描完成，共检测到 {len(self.results)} 项")
        return self.results
    
    def _get_java_version(self, command: str, version_flag: str) -> str:
        """获取 Java 版本（特殊处理）"""
        import re
        # Java 版本信息在 stderr
        output = self._run_command(f"{command} {version_flag}", capture_stderr=True)
        
        if output:
            # Java 版本输出在 stderr，格式如: java version "1.8.0_291" 或 openjdk version "17.0.1"
            # 尝试多种模式
            patterns = [
                r'version "([^"]+)"',  # java version "1.8.0_291"
                r'version ([0-9]+\.[0-9]+\.[0-9]+)',  # version 17.0.1
                r'([0-9]+\.[0-9]+\.[0-9]+)',  # 直接匹配版本号
            ]
            
            for pattern in patterns:
                match = re.search(pattern, output)
                if match:
                    return match.group(1)
        
        return None
    
    def _get_maven_version(self) -> str:
        """获取 Maven 版本（特殊处理）"""
        import re
        output = self._run_command("mvn --version")
        
        if output:
            # Maven 输出格式: Apache Maven 3.8.6 (...)
            match = re.search(r'Apache Maven ([0-9]+\.[0-9]+\.[0-9]+)', output)
            if match:
                return match.group(1)
        
        return None
    
    def _get_csc_version(self) -> str:
        """获取 C# 编译器版本（特殊处理）"""
        import re
        
        # csc 可能不在 PATH 中，尝试从 .NET SDK 路径查找
        output = self._run_command("csc /version")
        
        if output:
            # 输出格式: Microsoft (R) Visual C# Compiler version 4.x.x
            match = re.search(r'version ([0-9]+\.[0-9]+\.[0-9]+)', output)
            if match:
                return match.group(1)
        
        # 如果 csc 不可用，尝试通过 dotnet 检测
        dotnet_output = self._run_command("dotnet --version")
        if dotnet_output:
            return f".NET {dotnet_output.strip()}"
        
        return None
