"""环境恢复主程序"""
import sys
import os
from pathlib import Path
import webbrowser
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from utils.logger import setup_logger, log_section
from utils.config_manager import ConfigManager
from installers.auto_installer import AutoInstaller
from installers.guide_generator import GuideGenerator


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python restore.py <配置文件路径>")
        print("示例: python restore.py environment_config.json")
        sys.exit(1)
    
    config_file = sys.argv[1]
    
    if not Path(config_file).exists():
        print(f"错误: 配置文件不存在: {config_file}")
        sys.exit(1)
    
    # 设置日志
    log_file = f"logs/restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    logger = setup_logger(log_file=log_file)
    
    log_section("ProgrammerER - 环境恢复工具")
    logger.info(f"配置文件: {config_file}\n")
    
    # 加载配置
    config_manager = ConfigManager()
    config_data = config_manager.load(config_file)
    
    # 显示配置信息
    metadata = config_data.get("metadata", {})
    logger.info(f"原始环境信息:")
    logger.info(f"  操作系统: {metadata.get('os', 'Unknown')}")
    logger.info(f"  导出日期: {metadata.get('export_date', 'Unknown')}")
    logger.info(f"  主机名: {metadata.get('hostname', 'Unknown')}")
    
    stats = config_data.get("statistics", {})
    logger.info(f"\n环境统计:")
    logger.info(f"  总计: {stats.get('total_items', 0)} 项")
    logger.info(f"  可自动安装: {stats.get('auto_install_count', 0)} 项")
    logger.info(f"  需手动安装: {stats.get('manual_install_count', 0)} 项")
    logger.info(f"  需手动配置: {stats.get('manual_config_count', 0)} 项")
    
    # 询问用户是否继续
    print("\n" + "="*60)
    response = input("是否开始自动安装? (y/n): ")
    if response.lower() != 'y':
        logger.info("用户取消安装")
        sys.exit(0)
    
    # 执行自动安装
    log_section("阶段 1/2: 自动安装")
    installer = AutoInstaller(logger)
    result = installer.install_all(config_data)
    
    logger.info(f"\n自动安装完成:")
    logger.info(f"  ✓ 成功: {result['success']} 项")
    logger.info(f"  ✗ 失败: {result['failed']} 项")
    logger.info(f"  ⊘ 跳过: {result['skipped']} 项")
    
    if result['failed_items']:
        logger.warning(f"\n失败项目:")
        for item in result['failed_items']:
            logger.warning(f"  - {item}")
    
    # 生成手动安装指南
    log_section("阶段 2/2: 手动安装指南")
    logger.info("正在生成手动安装指南...")
    
    # 转换手动安装项为 ScanResult 格式
    manual_items = []
    for category, items in config_data.get("manual_install", {}).items():
        manual_items.extend(items)
    
    generator = GuideGenerator(logger)
    
    # 创建简化的结果对象
    class SimpleResult:
        def __init__(self, data):
            self.data = data
            self.install_method = data.get('install_method', 'manual')
            self.priority = data.get('priority', 3)
        
        def to_dict(self):
            return self.data
    
    manual_results = [SimpleResult(item) for item in manual_items]
    
    html_path = generator.generate_scan_report(
        [],  # 自动安装项已经安装，不需要显示
        {"total_items": len(manual_items), "auto_install_count": 0, 
         "manual_install_count": len(manual_items), "manual_config_count": 0}
    )
    
    # 重新生成只包含手动项的报告
    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProgrammerER - 手动安装清单</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <header class="bg-gradient-to-r from-green-600 to-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-6">
                <h1 class="text-3xl font-bold">✅ 自动安装已完成</h1>
                <p class="text-green-100 mt-2">以下是需要手动安装的项目清单</p>
            </div>
        </header>

        <div class="container mx-auto px-4 py-8">
            <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">📋 手动安装清单 ({len(manual_items)} 项)</h2>
                <p class="text-gray-600 mb-6">请按照优先级依次安装以下项目</p>
                
                {generator._generate_manual_install_cards(manual_results)}
            </div>

            <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <h3 class="font-bold text-green-800 mb-2">✅ 安装进度</h3>
                <ul class="text-green-700 space-y-1 text-sm">
                    <li>• 自动安装: {result['success']}/{stats.get('auto_install_count', 0)} 项成功</li>
                    <li>• 手动安装: 请完成上述 {len(manual_items)} 项</li>
                    <li>• 安装完成后，建议运行验证命令确认</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                alert('已复制到剪贴板: ' + text);
            }});
        }}
    </script>
</body>
</html>"""
    
    manual_guide_path = Path(f"manual_install_guide_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
    with open(manual_guide_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    logger.info(f"✓ 手动安装指南已生成: {manual_guide_path}")
    
    # 打开指南
    logger.info("\n正在浏览器中打开手动安装指南...")
    try:
        webbrowser.open(str(manual_guide_path.absolute()))
        logger.info("✓ 指南已在浏览器中打开")
    except Exception as e:
        logger.warning(f"无法自动打开浏览器: {e}")
        logger.info(f"请手动打开: {manual_guide_path}")
    
    log_section("恢复完成")
    logger.info(f"自动安装: {result['success']}/{stats.get('auto_install_count', 0)} 成功")
    logger.info(f"手动安装指南: {manual_guide_path}")
    logger.info(f"日志文件: {log_file}")
    logger.info("\n请按照手动安装指南完成剩余项目的安装")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n用户中断恢复")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
