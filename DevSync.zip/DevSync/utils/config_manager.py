"""配置文件管理模块"""
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List
import platform


class ConfigManager:
    """配置文件管理器"""
    
    def __init__(self, config_path: str = None):
        """
        初始化配置管理器
        
        Args:
            config_path: 配置文件路径
        """
        self.config_path = Path(config_path) if config_path else None
        self.config_data = self._init_config_structure()
    
    def _init_config_structure(self) -> Dict[str, Any]:
        """初始化配置文件结构"""
        return {
            "metadata": {
                "export_date": datetime.now().isoformat(),
                "os": platform.system(),
                "os_version": platform.version(),
                "hostname": platform.node(),
                "username": "",  # 将在扫描时填充
                "tool_version": "1.0.0"
            },
            "auto_install": {
                "python_packages": [],
                "npm_global_packages": [],
                "vscode_extensions": [],
                "chocolatey_packages": [],
                "scoop_packages": []
            },
            "manual_install": {
                "languages": [],
                "ides": [],
                "databases": [],
                "tools": [],
                "commercial_software": []
            },
            "manual_config": {
                "git_config": {},
                "environment_variables": [],
                "ssh_keys": {},
                "other_configs": []
            },
            "statistics": {
                "total_items": 0,
                "auto_install_count": 0,
                "manual_install_count": 0,
                "manual_config_count": 0
            }
        }
    
    def add_auto_install_item(self, category: str, item: Dict[str, Any]):
        """
        添加自动安装项
        
        Args:
            category: 类别（如 python_packages, vscode_extensions）
            item: 项目信息
        """
        if category in self.config_data["auto_install"]:
            self.config_data["auto_install"][category].append(item)
            self.config_data["statistics"]["auto_install_count"] += 1
            self.config_data["statistics"]["total_items"] += 1
    
    def add_manual_install_item(self, category: str, item: Dict[str, Any]):
        """
        添加手动安装项
        
        Args:
            category: 类别（如 languages, ides）
            item: 项目信息
        """
        if category in self.config_data["manual_install"]:
            self.config_data["manual_install"][category].append(item)
            self.config_data["statistics"]["manual_install_count"] += 1
            self.config_data["statistics"]["total_items"] += 1
    
    def add_manual_config_item(self, category: str, key: str, value: Any):
        """
        添加手动配置项
        
        Args:
            category: 类别
            key: 配置键
            value: 配置值
        """
        if category in self.config_data["manual_config"]:
            if isinstance(self.config_data["manual_config"][category], dict):
                self.config_data["manual_config"][category][key] = value
            elif isinstance(self.config_data["manual_config"][category], list):
                self.config_data["manual_config"][category].append({key: value})
            self.config_data["statistics"]["manual_config_count"] += 1
            self.config_data["statistics"]["total_items"] += 1
    
    def save(self, output_path: str = None):
        """
        保存配置到文件
        
        Args:
            output_path: 输出文件路径（可选）
        """
        save_path = Path(output_path) if output_path else self.config_path
        
        if not save_path:
            save_path = Path(f"environment_config_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        
        save_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(self.config_data, f, indent=2, ensure_ascii=False)
        
        return save_path
    
    def load(self, config_path: str = None):
        """
        从文件加载配置
        
        Args:
            config_path: 配置文件路径
        """
        load_path = Path(config_path) if config_path else self.config_path
        
        if not load_path or not load_path.exists():
            raise FileNotFoundError(f"配置文件不存在: {load_path}")
        
        with open(load_path, 'r', encoding='utf-8') as f:
            self.config_data = json.load(f)
        
        return self.config_data
    
    def get_auto_install_items(self) -> Dict[str, List]:
        """获取所有自动安装项"""
        return self.config_data["auto_install"]
    
    def get_manual_install_items(self) -> Dict[str, List]:
        """获取所有手动安装项"""
        return self.config_data["manual_install"]
    
    def get_manual_config_items(self) -> Dict[str, Any]:
        """获取所有手动配置项"""
        return self.config_data["manual_config"]
    
    def get_statistics(self) -> Dict[str, int]:
        """获取统计信息"""
        return self.config_data["statistics"]
    
    def update_metadata(self, key: str, value: Any):
        """更新元数据"""
        self.config_data["metadata"][key] = value
