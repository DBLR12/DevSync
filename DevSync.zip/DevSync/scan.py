"""环境扫描主程序"""
import sys
import os
from pathlib import Path
import webbrowser
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from utils.logger import setup_logger, log_section
from utils.config_manager import ConfigManager
from scanners.language_scanner import LanguageScanner
from scanners.package_scanner import PackageScanner
from scanners.vscode_scanner import VSCodeScanner
from scanners.version_manager_scanner import VersionManagerScanner
from scanners.jdk_scanner import JDKScanner
from installers.guide_generator import GuideGenerator


def main():
    """主函数"""
    # 设置日志
    log_file = f"logs/scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    logger = setup_logger(log_file=log_file)
    
    log_section("ProgrammerER - 环境扫描工具")
    logger.info("开始扫描开发环境...\n")
    
    # 初始化配置管理器
    config_manager = ConfigManager()
    config_manager.update_metadata("username", os.getenv("USERNAME", "unknown"))
    
    # 创建扫描器
    scanners = [
        ("版本管理工具", VersionManagerScanner(logger)),
        ("JDK 多版本", JDKScanner(logger)),
        ("编程语言", LanguageScanner(logger)),
        ("包管理器", PackageScanner(logger)),
        ("VSCode插件", VSCodeScanner(logger))
    ]
    
    # 执行扫描
    all_results = []
    for scanner_name, scanner in scanners:
        log_section(f"扫描 {scanner_name}")
        try:
            results = scanner.scan()
            all_results.extend(results)
            
            # 将结果添加到配置
            for result in results:
                result_dict = result.to_dict()
                
                if result.install_method == "auto":
                    # 自动安装项
                    if result.item_type == "package":
                        pm = result_dict.get("package_manager", "unknown")
                        category = f"{pm}_packages" if pm != "unknown" else "other_packages"
                        if category in config_manager.config_data["auto_install"]:
                            config_manager.add_auto_install_item(category, result_dict)
                    elif result.item_type == "ide_plugin":
                        config_manager.add_auto_install_item("vscode_extensions", result_dict)
                elif result.install_method == "semi_auto":
                    # 半自动安装项（如 nvm 管理的版本）
                    if result.item_type == "language":
                        config_manager.add_manual_install_item("languages", result_dict)
                else:
                    # 手动安装项
                    if result.item_type == "language":
                        config_manager.add_manual_install_item("languages", result_dict)
                    elif result.item_type == "tool":
                        config_manager.add_manual_install_item("tools", result_dict)
            
            logger.info("")
        except Exception as e:
            logger.error(f"扫描 {scanner_name} 时出错: {e}\n")
    
    # 保存配置文件
    log_section("保存配置")
    config_path = config_manager.save()
    logger.info(f"✓ 配置文件已保存: {config_path}")
    
    # 生成 HTML 报告
    logger.info("正在生成可视化报告...")
    generator = GuideGenerator(logger)
    html_path = generator.generate_scan_report(
        all_results,
        config_manager.get_statistics()
    )
    logger.info(f"✓ HTML 报告已生成: {html_path}")
    
    # 显示统计信息
    log_section("扫描统计")
    stats = config_manager.get_statistics()
    logger.info(f"总计检测项目: {stats['total_items']}")
    logger.info(f"  🟢 可自动安装: {stats['auto_install_count']}")
    logger.info(f"  🟡 需手动安装: {stats['manual_install_count']}")
    logger.info(f"  🔴 需手动配置: {stats['manual_config_count']}")
    
    # 打开 HTML 报告
    logger.info("\n正在浏览器中打开报告...")
    try:
        webbrowser.open(str(html_path.absolute()))
        logger.info("✓ 报告已在浏览器中打开")
    except Exception as e:
        logger.warning(f"无法自动打开浏览器: {e}")
        logger.info(f"请手动打开: {html_path}")
    
    log_section("扫描完成")
    logger.info(f"配置文件: {config_path}")
    logger.info(f"可视化报告: {html_path}")
    logger.info(f"日志文件: {log_file}")
    logger.info("\n在新机器上运行: python restore.py {config_path}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n用户中断扫描")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
