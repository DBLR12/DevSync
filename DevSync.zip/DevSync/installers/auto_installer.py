"""自动安装器"""
import subprocess
from typing import Dict, List, Any
from pathlib import Path


class AutoInstaller:
    """自动安装器"""
    
    def __init__(self, logger=None):
        self.logger = logger
        self.success_count = 0
        self.fail_count = 0
        self.skip_count = 0
        self.failed_items = []
    
    def install_all(self, config_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        安装所有自动安装项
        
        Args:
            config_data: 配置数据
        
        Returns:
            Dict: 安装结果统计
        """
        auto_install = config_data.get("auto_install", {})
        
        self.log_info("开始自动安装...")
        
        # 安装 Python 包
        if auto_install.get("python_packages"):
            self._install_pip_packages(auto_install["python_packages"])
        
        # 安装 npm 全局包
        if auto_install.get("npm_global_packages"):
            self._install_npm_packages(auto_install["npm_global_packages"])
        
        # 安装 VSCode 扩展
        if auto_install.get("vscode_extensions"):
            self._install_vscode_extensions(auto_install["vscode_extensions"])
        
        # 安装 Chocolatey 包
        if auto_install.get("chocolatey_packages"):
            self._install_chocolatey_packages(auto_install["chocolatey_packages"])
        
        return {
            "success": self.success_count,
            "failed": self.fail_count,
            "skipped": self.skip_count,
            "failed_items": self.failed_items
        }
    
    def _install_pip_packages(self, packages: List[Dict]):
        """安装 pip 包"""
        self.log_info(f"\n安装 Python 包 ({len(packages)} 个)...")
        
        for pkg in packages:
            name = pkg.get("name")
            version = pkg.get("version")
            
            try:
                self.log_info(f"  安装 {name}=={version}...")
                result = subprocess.run(
                    f"pip install {name}=={version}",
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                
                if result.returncode == 0:
                    self.log_info(f"    ✓ 成功")
                    self.success_count += 1
                else:
                    self.log_warning(f"    ✗ 失败: {result.stderr[:100]}")
                    self.fail_count += 1
                    self.failed_items.append(f"pip: {name}")
            except Exception as e:
                self.log_error(f"    ✗ 错误: {e}")
                self.fail_count += 1
                self.failed_items.append(f"pip: {name}")
    
    def _install_npm_packages(self, packages: List[Dict]):
        """安装 npm 全局包"""
        self.log_info(f"\n安装 npm 全局包 ({len(packages)} 个)...")
        
        for pkg in packages:
            name = pkg.get("name")
            version = pkg.get("version")
            
            try:
                self.log_info(f"  安装 {name}@{version}...")
                result = subprocess.run(
                    f"npm install -g {name}@{version}",
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                
                if result.returncode == 0:
                    self.log_info(f"    ✓ 成功")
                    self.success_count += 1
                else:
                    self.log_warning(f"    ✗ 失败: {result.stderr[:100]}")
                    self.fail_count += 1
                    self.failed_items.append(f"npm: {name}")
            except Exception as e:
                self.log_error(f"    ✗ 错误: {e}")
                self.fail_count += 1
                self.failed_items.append(f"npm: {name}")
    
    def _install_vscode_extensions(self, extensions: List[Dict]):
        """安装 VSCode 扩展"""
        self.log_info(f"\n安装 VSCode 扩展 ({len(extensions)} 个)...")
        
        for ext in extensions:
            name = ext.get("name")
            
            try:
                self.log_info(f"  安装 {name}...")
                result = subprocess.run(
                    f"code --install-extension {name}",
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                
                if result.returncode == 0:
                    self.log_info(f"    ✓ 成功")
                    self.success_count += 1
                else:
                    self.log_warning(f"    ✗ 失败: {result.stderr[:100]}")
                    self.fail_count += 1
                    self.failed_items.append(f"vscode: {name}")
            except Exception as e:
                self.log_error(f"    ✗ 错误: {e}")
                self.fail_count += 1
                self.failed_items.append(f"vscode: {name}")
    
    def _install_chocolatey_packages(self, packages: List[Dict]):
        """安装 Chocolatey 包"""
        self.log_info(f"\n安装 Chocolatey 包 ({len(packages)} 个)...")
        
        for pkg in packages:
            name = pkg.get("name")
            version = pkg.get("version")
            
            try:
                self.log_info(f"  安装 {name}...")
                result = subprocess.run(
                    f"choco install {name} --version={version} -y",
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=600
                )
                
                if result.returncode == 0:
                    self.log_info(f"    ✓ 成功")
                    self.success_count += 1
                else:
                    self.log_warning(f"    ✗ 失败: {result.stderr[:100]}")
                    self.fail_count += 1
                    self.failed_items.append(f"choco: {name}")
            except Exception as e:
                self.log_error(f"    ✗ 错误: {e}")
                self.fail_count += 1
                self.failed_items.append(f"choco: {name}")
    
    def log_info(self, message: str):
        """记录信息"""
        if self.logger:
            self.logger.info(message)
        else:
            print(message)
    
    def log_warning(self, message: str):
        """记录警告"""
        if self.logger:
            self.logger.warning(message)
        else:
            print(message)
    
    def log_error(self, message: str):
        """记录错误"""
        if self.logger:
            self.logger.error(message)
        else:
            print(message)
