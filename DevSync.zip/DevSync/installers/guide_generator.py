"""HTML 安装指南生成器"""
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any


class GuideGenerator:
    """HTML 安装指南生成器"""
    
    def __init__(self, logger=None):
        self.logger = logger
        self.template_dir = Path(__file__).parent.parent / "templates"
        self.template_dir.mkdir(exist_ok=True)
    
    def generate_scan_report(self, results: List, statistics: Dict[str, int]) -> Path:
        """
        生成扫描报告
        
        Args:
            results: 扫描结果列表
            statistics: 统计信息
        
        Returns:
            Path: HTML 文件路径
        """
        # 分类结果
        auto_install = []
        manual_install = []
        
        for r in results:
            # 获取 install_method
            if hasattr(r, 'install_method'):
                method = r.install_method
            elif hasattr(r, 'to_dict'):
                method = r.to_dict().get('install_method', 'manual')
            else:
                method = 'manual'
            
            # 分类
            if method == "auto":
                auto_install.append(r)
            elif method in ["manual", "semi_auto"]:
                manual_install.append(r)
        
        # 生成 HTML
        html_content = self._generate_html(
            auto_install,
            manual_install,
            statistics
        )
        
        # 保存文件
        output_path = Path(f"scan_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return output_path
    
    def _generate_html(
        self,
        auto_install: List,
        manual_install: List,
        statistics: Dict[str, int]
    ) -> str:
        """生成 HTML 内容"""
        
        # 生成自动安装项表格
        auto_install_html = self._generate_auto_install_table(auto_install)
        
        # 生成手动安装项表格
        manual_install_html = self._generate_manual_install_table(manual_install)
        
        # 完整 HTML
        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>环境扫描报告 - ProgrammerER</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
        
        /* 头部 */
        header {{ 
            background: #fff;
            border-bottom: 2px solid #e0e0e0;
            padding: 20px 0;
            margin-bottom: 30px;
        }}
        header h1 {{ font-size: 24px; font-weight: 600; margin-bottom: 5px; }}
        header .meta {{ color: #666; font-size: 14px; }}
        
        /* 搜索框 */
        .search-box {{
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid #e0e0e0;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #4a90e2;
        }}
        
        /* 统计卡片 */
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: #fff;
            padding: 20px;
            border-radius: 4px;
            border: 1px solid #e0e0e0;
        }}
        .stat-card .label {{ font-size: 13px; color: #666; margin-bottom: 8px; }}
        .stat-card .value {{ font-size: 28px; font-weight: 600; }}
        
        /* 表格容器 */
        .section {{
            background: #fff;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid #e0e0e0;
            overflow: hidden;
        }}
        .section-header {{
            padding: 16px 20px;
            background: #fafafa;
            border-bottom: 1px solid #e0e0e0;
            font-weight: 600;
            font-size: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .section-header .count {{ 
            color: #666; 
            font-weight: normal; 
            font-size: 14px; 
        }}
        
        /* 表格 */
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        thead {{
            background: #f9f9f9;
            border-bottom: 2px solid #e0e0e0;
        }}
        th {{
            padding: 12px 16px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: #555;
        }}
        td {{
            padding: 12px 16px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
        }}
        tbody tr:hover {{
            background: #fafafa;
        }}
        tbody tr.hidden {{
            display: none;
        }}
        
        /* 标签 */
        .tag {{
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 500;
        }}
        .tag-language {{ background: #e3f2fd; color: #1976d2; }}
        .tag-package {{ background: #f3e5f5; color: #7b1fa2; }}
        .tag-plugin {{ background: #e8f5e9; color: #388e3c; }}
        .tag-tool {{ background: #fff3e0; color: #f57c00; }}
        
        /* 优先级 */
        .priority {{
            display: inline-flex;
            align-items: center;
            gap: 2px;
        }}
        .priority-5 {{ color: #d32f2f; }}
        .priority-4 {{ color: #f57c00; }}
        .priority-3 {{ color: #fbc02d; }}
        .priority-2 {{ color: #1976d2; }}
        .priority-1 {{ color: #757575; }}
        
        /* 路径 */
        .path {{
            font-family: 'Courier New', monospace;
            font-size: 12px;
            color: #666;
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
        }}
        
        /* 描述 */
        .description {{
            color: #666;
            font-size: 12px;
            max-width: 400px;
        }}
        
        /* 链接 */
        a {{
            color: #4a90e2;
            text-decoration: none;
        }}
        a:hover {{
            text-decoration: underline;
        }}
        
        /* 无结果提示 */
        .no-results {{
            padding: 40px;
            text-align: center;
            color: #999;
            display: none;
        }}
        
        /* 响应式 */
        @media (max-width: 768px) {{
            .stats {{ grid-template-columns: 1fr; }}
            table {{ font-size: 12px; }}
            th, td {{ padding: 8px 12px; }}
        }}
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>环境扫描报告</h1>
            <div class="meta">导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | ProgrammerER v1.0</div>
        </div>
    </header>

    <div class="container">
        <!-- 搜索框 -->
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="搜索包名、语言、路径..." 
                   onkeyup="filterTable()">
        </div>

        <!-- 统计卡片 -->
        <div class="stats">
            <div class="stat-card">
                <div class="label">总计项目</div>
                <div class="value">{statistics.get('total_items', 0)}</div>
            </div>
            <div class="stat-card">
                <div class="label">可自动安装</div>
                <div class="value" style="color: #4caf50;">{statistics.get('auto_install_count', 0)}</div>
            </div>
            <div class="stat-card">
                <div class="label">需手动安装</div>
                <div class="value" style="color: #ff9800;">{statistics.get('manual_install_count', 0)}</div>
            </div>
            <div class="stat-card">
                <div class="label">需手动配置</div>
                <div class="value" style="color: #f44336;">{statistics.get('manual_config_count', 0)}</div>
            </div>
        </div>

        <!-- 自动安装项 -->
        <div class="section">
            <div class="section-header">
                <span>可自动安装</span>
                <span class="count">{len(auto_install)} 项</span>
            </div>
            {auto_install_html}
        </div>

        <!-- 手动安装项 -->
        <div class="section">
            <div class="section-header">
                <span>需手动安装</span>
                <span class="count">{len(manual_install)} 项</span>
            </div>
            {manual_install_html}
        </div>

        <div class="no-results" id="noResults">
            未找到匹配的项目
        </div>
    </div>

    <script>
        function filterTable() {{
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const tables = document.querySelectorAll('table tbody');
            let visibleCount = 0;
            
            tables.forEach(tbody => {{
                const rows = tbody.getElementsByTagName('tr');
                for (let row of rows) {{
                    const text = row.textContent.toLowerCase();
                    if (text.includes(filter)) {{
                        row.classList.remove('hidden');
                        visibleCount++;
                    }} else {{
                        row.classList.add('hidden');
                    }}
                }}
            }});
            
            // 显示/隐藏无结果提示
            const noResults = document.getElementById('noResults');
            if (visibleCount === 0 && filter !== '') {{
                noResults.style.display = 'block';
            }} else {{
                noResults.style.display = 'none';
            }}
        }}
        
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                alert('已复制: ' + text);
            }});
        }}
    </script>
</body>
</html>"""
        
        return html
    
    def _generate_auto_install_table(self, items: List) -> str:
        """生成自动安装项表格"""
        if not items:
            return '<p style="padding: 20px; color: #999;">未检测到可自动安装的项目</p>'
        
        rows = []
        for item in items:
            item_dict = item.to_dict() if hasattr(item, 'to_dict') else item
            
            # 获取详细信息
            name = item_dict.get('name', 'Unknown')
            version = item_dict.get('version', 'N/A')
            item_type = item_dict.get('item_type', 'unknown')
            
            # 特殊处理：显示是否由版本管理工具管理
            managed_by = item_dict.get('managed_by', '')
            is_current = item_dict.get('is_current', False)
            if managed_by:
                name = f"{name} {'★' if is_current else ''}"
            
            package_manager = item_dict.get('package_manager', item_dict.get('detection_source', 'N/A'))
            
            # 获取路径信息
            path = self._get_item_path(item_dict)
            
            # 获取描述
            description = self._get_item_description(item_dict)
            
            # 类型标签
            type_class = f"tag-{item_type}"
            type_label = {
                'language': '语言',
                'package': '包',
                'ide_plugin': '插件',
                'tool': '工具'
            }.get(item_type, item_type)
            
            rows.append(f"""
                <tr>
                    <td><strong>{name}</strong></td>
                    <td>{version}</td>
                    <td><span class="tag {type_class}">{type_label}</span></td>
                    <td>{package_manager}</td>
                    <td><span class="path">{path}</span></td>
                    <td class="description">{description}</td>
                </tr>
            """)
        
        return f"""
            <table>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>版本</th>
                        <th>类型</th>
                        <th>所属环境</th>
                        <th>路径</th>
                        <th>说明</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>
        """
    
    def _generate_manual_install_table(self, items: List) -> str:
        """生成手动安装项表格"""
        if not items:
            return '<p style="padding: 20px; color: #999;">未检测到需要手动安装的项目</p>'
        
        # 按优先级排序
        sorted_items = sorted(items, key=lambda x: x.priority if hasattr(x, 'priority') else 3, reverse=True)
        
        rows = []
        for item in sorted_items:
            item_dict = item.to_dict() if hasattr(item, 'to_dict') else item
            
            # 获取详细信息
            name = item_dict.get('name', 'Unknown')
            version = item_dict.get('version', 'N/A')
            item_type = item_dict.get('item_type', 'unknown')
            priority = item_dict.get('priority', 3)
            
            # 优先级星级
            stars = '★' * priority
            priority_class = f"priority-{priority}"
            
            # 类型标签
            type_class = f"tag-{item_type}"
            type_label = {
                'language': '语言',
                'package': '包',
                'ide_plugin': '插件',
                'tool': '工具',
                'database': '数据库'
            }.get(item_type, item_type)
            
            # 下载链接
            download_url = item_dict.get('download_url', '')
            download_link = f'<a href="{download_url}" target="_blank">下载</a>' if download_url else '-'
            
            # 安装说明
            install_guide = item_dict.get('install_guide', '无特殊说明')
            
            # 验证命令
            verify_cmd = item_dict.get('verify_command', '')
            verify_btn = f'<button onclick="copyToClipboard(\'{verify_cmd}\')" style="padding: 4px 8px; background: #f0f0f0; border: 1px solid #ddd; border-radius: 3px; cursor: pointer; font-size: 12px;">复制</button>' if verify_cmd else '-'
            
            rows.append(f"""
                <tr>
                    <td><strong>{name}</strong></td>
                    <td>{version}</td>
                    <td><span class="tag {type_class}">{type_label}</span></td>
                    <td><span class="{priority_class}">{stars}</span></td>
                    <td>{download_link}</td>
                    <td class="description">{install_guide}</td>
                    <td>{verify_btn}</td>
                </tr>
            """)
        
        return f"""
            <table>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>版本</th>
                        <th>类型</th>
                        <th>优先级</th>
                        <th>下载</th>
                        <th>安装说明</th>
                        <th>验证</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>
        """
    
    def _get_item_path(self, item_dict: Dict) -> str:
        """获取项目路径"""
        # 特殊处理：版本管理工具管理的版本
        managed_by = item_dict.get('managed_by', '')
        if managed_by:
            return f"{managed_by} 管理"
        
        # 根据不同类型返回路径
        package_manager = item_dict.get('package_manager', '')
        
        if package_manager == 'pip':
            return 'Python/site-packages'
        elif package_manager == 'npm':
            scope = item_dict.get('scope', 'local')
            return 'Node.js/global' if scope == 'global' else 'Node.js/local'
        elif item_dict.get('ide') == 'vscode':
            return '~/.vscode/extensions'
        elif package_manager == 'chocolatey':
            return 'C:/ProgramData/chocolatey'
        
        return item_dict.get('detection_source', '-')
    
    def _get_item_description(self, item_dict: Dict) -> str:
        """获取项目描述"""
        # 优先使用 notes 字段
        notes = item_dict.get('notes', '')
        if notes:
            return notes
        
        name = item_dict.get('name', '').lower()
        
        # 常见包的描述
        descriptions = {
            # Python 包
            'numpy': '数值计算库',
            'pandas': '数据分析库',
            'requests': 'HTTP请求库',
            'flask': 'Web框架',
            'django': 'Web框架',
            'pytest': '测试框架',
            'matplotlib': '数据可视化',
            'scikit-learn': '机器学习库',
            'tensorflow': '深度学习框架',
            'torch': '深度学习框架',
            'pillow': '图像处理库',
            'beautifulsoup4': 'HTML解析库',
            'selenium': '浏览器自动化',
            'sqlalchemy': 'ORM框架',
            
            # npm 包
            'typescript': 'TypeScript编译器',
            'webpack': '模块打包工具',
            'eslint': '代码检查工具',
            'prettier': '代码格式化',
            'nodemon': '自动重启工具',
            'express': 'Web框架',
            'react': '前端框架',
            'vue': '前端框架',
            'axios': 'HTTP客户端',
            
            # VSCode 插件
            'ms-python.python': 'Python语言支持',
            'esbenp.prettier-vscode': '代码格式化',
            'dbaeumer.vscode-eslint': 'ESLint集成',
        }
        
        # 返回预定义描述或默认描述
        return descriptions.get(name, '-')
